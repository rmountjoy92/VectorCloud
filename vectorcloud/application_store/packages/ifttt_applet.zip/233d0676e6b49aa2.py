#!/usr/bin/env python3

import os
import requests
from configparser import ConfigParser
from vectorcloud.paths import lib_folder

config = ConfigParser()
curr_hex = os.path.basename(__file__)
curr_hex = curr_hex.replace('.py', '')
config_file = os.path.join(lib_folder, curr_hex + '.ini')

f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
key = config.get(name, 'key')
applet_name = config.get(name, 'applet_name')
ifttt_url = 'https://maker.ifttt.com/trigger/' + applet_name +\
    '/with/key/' + key


def main():
    if key == 'xxxxxxxxxxxxxxxxxxxxxx':
        print('You have to put in your key in the app settings.')

    else:
        output = requests.post(ifttt_url)
        print(output)


if __name__ == "__main__":
    main()
