#!/usr/bin/env python3

import os
import anki_vector
import time
from anki_vector.util import degrees
from configparser import ConfigParser
from PIL import Image, ImageDraw, ImageFont
from vectorcloud.models import Application
from vectorcloud.paths import lib_folder

curr_hex = os.path.basename(__file__)
curr_hex = curr_hex.replace('.py', '')
application = Application.query.filter_by(hex_id=curr_hex).first()
hex_id = application.hex_id
config_file = os.path.join(lib_folder, hex_id + '.ini')

config = ConfigParser()
f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
text_to_show = config.get(name, 'text_to_show')
sleep_duration = config.get(name, 'sleep_duration')
font_size = config.get(name, 'font_size')

font = ImageFont.truetype(os.path.join(lib_folder, 'DroidSans-Bold.ttf'),
                          int(font_size))


def make_text_image(text_to_show, x, y, font=None):
    '''Make a PIL.Image with the given text printed on it

    Args:
        text_to_draw (string): the text to draw to the image
        x (int): x pixel location
        y (int): y pixel location
        font (PIL.ImageFont): the font to use

    Returns:
        :class:(`PIL.Image.Image`): a PIL image with the text drawn on it
    '''
    dimensions = (184, 96)

    # make a blank image for the text, initialized to opaque black
    text_image = Image.new(
        'RGBA', dimensions, (0, 0, 0, 255))

    # get a drawing context
    dc = ImageDraw.Draw(text_image)

    # draw the text
    dc.text((x, y), text_to_show, fill=(255, 255, 255, 255), font=font)

    return text_image


def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        # Set text to create image from here
        face_image = make_text_image(text_to_show, 30, 20, font)

        # If necessary, Move Vector's Head and Lift to make
        # it easy to see his face
        robot.behavior.set_head_angle(degrees(50.0))
        robot.behavior.set_lift_height(0.0)

        # Convert the image to the format used by the Screen
        print("Displaying " + text_to_show + '...')
        screen_data = anki_vector.screen.convert_image_to_screen_data(
            face_image)
        robot.screen.set_screen_with_image_data(
            screen_data, float(sleep_duration))

        time.sleep(int(sleep_duration))


if __name__ == "__main__":
    main()
