#!/usr/bin/env python3


# VectorCloud database integration example

from time import sleep
import anki_vector


def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        while True:
            robot.say_text('test')
            sleep(10)


if __name__ == "__main__":
    main()
