#!/usr/bin/env python3

import anki_vector
from vectorcloud import db
from vectorcloud.models import AppPrompt


def main():
    prompt = AppPrompt(question='Type something for Vector to say..',
                       answer=None,
                       output=None)
    db.session.add(prompt)
    db.session.commit()

    while True:
        db.session.expire_all()
        prompt = AppPrompt.query.first()
        if prompt:
            if prompt.answer is None:
                pass
            else:
                args = anki_vector.util.parse_command_args()
                with anki_vector.Robot(args.serial) as robot:
                    robot.say_text(prompt.answer)

                prompt.output = "Said " + prompt.answer
                prompt.answer = None
                db.session.merge(prompt)
                db.session.commit()

        else:
            print('Success!')
            break


if __name__ == "__main__":
    main()
