#!/usr/bin/env python3

import os
import requests
import anki_vector
from vectorcloud.main.utils import config
from vectorcloud.models import Application

curr_folder = os.path.dirname(os.path.realpath(__file__))
application = Application.query.filter_by(script_name='Say Text').first()
hex_id = application.hex_id
lib_folder = os.path.join(curr_folder, 'lib')
config_file = os.path.join(lib_folder, hex_id + '.ini')

f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
key = config.get(name, 'YOUR_AZURE_SUBSCRIPTION_KEY')
url = config.get(name, 'YOUR_AZURE_SUBSCRIPTION_ENDPOINT_URL')


def identify_image(image, image_id):
    headers = {'content-type': 'application/octet-stream'}
    params = {'visualFeatures': 'Description', 'subscription-key': key}
    filename = f"{image_id}.png"
    try:
        image.save(filename)
        fin = open(filename, 'rb')
        data = fin.read()
        # Make sure the url we are calling below corresponds to your Azure subscription
        # see this issue for more info (https://github.com/hassanhabib/anki_robot_with_azure/issues/1)
        response = requests.post(url + 'vision/v2.0/analyze',
                                 headers=headers, params=params, data=data)
        seen = response.json()['description']['captions'][0]['text']
        print(seen)
        return "I see " + seen
    finally:
        fin.close()
        os.remove(filename)


def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        try:
            image = robot.camera.latest_image
            image_id = robot._camera._latest_image_id
            seen = identify_image(image, image_id)
            robot.say_text(seen)
        except:
            robot.say_text("I didn't get that, try again!")


if __name__ == "__main__":
    main()
