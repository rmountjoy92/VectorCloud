#!/usr/bin/env python3

# Copyright (c) 2018 Anki, Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License in the file LICENSE.txt or at
#
#     https://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

"""Set Vector's eye color.
"""

import os
import time
import anki_vector
from vectorcloud.main.utils import config
from vectorcloud.models import Application

curr_folder = os.path.dirname(os.path.realpath(__file__))
# curr_file = os.path.basename(__file__)
# hex_id = curr_file.replace('.py', '')
application = Application.query.filter_by(script_name='Eye Color').first()
hex_id = application.hex_id
lib_folder = os.path.join(curr_folder, 'lib')
config_file = os.path.join(lib_folder, hex_id + '.ini')

f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
hue = config.get(name, 'hue')
saturation = config.get(name, 'saturation')
duration = config.get(name, 'duration')

hue_string = hue
saturation_string = saturation
duration_string = duration

hue = float(hue)
saturation = float(saturation)
duration = int(duration)


def main():
    args = anki_vector.util.parse_command_args()

    with anki_vector.Robot(args.serial) as robot:
        print("Set Vector's eye color to\nHue: " + hue_string +
              "... Saturation: " + saturation_string +
              "... Sleep " + duration_string + " seconds...")
        robot.behavior.set_eye_color(hue=hue, saturation=saturation)
        time.sleep(duration)


if __name__ == '__main__':
    main()
