#!/usr/bin/env python3

import os
import anki_vector
from vectorcloud.main.utils import config
from vectorcloud.models import Application

curr_folder = os.path.dirname(os.path.realpath(__file__))
application = Application.query.filter_by(script_name='Say Text').first()
hex_id = application.hex_id
lib_folder = os.path.join(curr_folder, 'lib')
config_file = os.path.join(lib_folder, hex_id + '.ini')

f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
text_to_say = config.get(name, 'text_to_say')


def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        print("Say " + text_to_say)
        robot.say_text(text_to_say)


if __name__ == "__main__":
    main()
