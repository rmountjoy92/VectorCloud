#!/usr/bin/env python3

import os
import anki_vector
from configparser import ConfigParser
from vectorcloud.paths import lib_folder

config = ConfigParser()
curr_hex = os.path.basename(__file__)
curr_hex = curr_hex.replace('.py', '')
config_file = os.path.join(lib_folder, curr_hex + '.ini')

f = open(config_file)
name = f.readline()
name = name.replace(']', '')
name = name.replace('[', '')
name = name.replace('\n', '')
f.close()
config.read(config_file)
text_to_say = config.get(name, 'text_to_say')


def main():
    args = anki_vector.util.parse_command_args()
    with anki_vector.Robot(args.serial) as robot:
        print("Say " + text_to_say)
        robot.say_text(text_to_say)


if __name__ == "__main__":
    main()
